package com.moecm.windcomment

import kotlinx.serialization.Serializable
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.json.Json
import okhttp3.*
import okio.IOException
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import kotlin.coroutines.suspendCoroutine

@Serializable
data class Comment(val avatar: String, val name: String, val content: String) {
    companion object {
        suspend fun request(url: String): List<Comment> = suspendCoroutine { continuation ->
            OkHttpClient().newCall(Request.Builder().url(url).build()).enqueue(object : Callback {
                override fun onFailure(call: Call, e: IOException) {
                    continuation.resumeWithException(e)
                }

                override fun onResponse(call: Call, response: Response) {
                    response.use {
                        if (!response.isSuccessful) {
                            continuation.resumeWithException(IOException("Unexpected code $response"))
                        }
                        val format = Json { ignoreUnknownKeys = true }
                        continuation.resume(format.decodeFromString(response.body!!.string()))
                    }
                }
            })
        }
    }
}
